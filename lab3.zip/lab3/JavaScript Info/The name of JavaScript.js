let answer = prompt("What is the official name of JavaScript?")
answer == "ECMAScript" ? alert("Right!") : alert("You don't know? ECMAScript!")let a = 1, b = 1;

            let c = ++a; // 2
            let d = b++; // 1