const BIRTHDAY = '18.04.1982';
const age = someCode(BIRTHDAY);
//birthday uppercase, age lowercase