5 > 4 // true
"apple" > "pineapple" // false , a char < p char
"2" > "12" // true , dictionary comparison 2 char > 1 char
undefined == null // true
undefined === null // false
null == "\n0\n" // false
null === +"\n0\n" // false