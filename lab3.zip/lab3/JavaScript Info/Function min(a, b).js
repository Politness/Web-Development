function min(a, b){
    return a>b ? b: a;
}   