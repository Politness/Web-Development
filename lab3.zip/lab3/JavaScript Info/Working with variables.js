let name, admin
name = "John"
admin = name
alert(admin)