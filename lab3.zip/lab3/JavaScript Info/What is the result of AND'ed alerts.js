alert( alert(1) && alert(2) ); // 1
