alert( alert(1) || 2 || alert(3) ); // 2
