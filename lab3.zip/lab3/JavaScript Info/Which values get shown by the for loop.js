for (let i = 0; i < 5; i++) alert( i ); // 0, 1, 2, 3, 4
for (let i = 0; i < 5; ++i) alert( i ); // 0, 1, 2, 3, 4