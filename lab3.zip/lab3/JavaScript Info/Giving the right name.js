let planet = "Earth"
    , visitor = "name_of_a_current_visitor"