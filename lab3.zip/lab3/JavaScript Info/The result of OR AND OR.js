alert( null || 2 && 3 || 4 ); // 3
