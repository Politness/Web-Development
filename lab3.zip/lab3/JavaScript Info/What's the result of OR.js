alert( null || 2 || undefined ); // 2
