if ("0") {
    alert( 'Hello' );  //will be shown
}