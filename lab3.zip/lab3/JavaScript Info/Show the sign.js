let num = prompt("Enter a number:")
if (num > 0){
    alert(1)
}
else if (num == 0){
    alert(0)
}
else if(num < 0){
    alert(-1)
}