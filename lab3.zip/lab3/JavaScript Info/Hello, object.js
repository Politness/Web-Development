let user = {
    name : John,
    surname : Smith,

}

user.name = Pete;
delete user.name;