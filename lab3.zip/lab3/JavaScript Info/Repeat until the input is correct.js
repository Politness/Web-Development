let input = prompt("100", "")
while(!(input > 100)){
    input =prompt("100", "")
    if(input = "" || input == none){
        break;
    }
}

/*
let num;

do {
  num = prompt("Enter a number greater than 100?", 0);
} while (num <= 100 && num);
*/