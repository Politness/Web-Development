if(age>90 || age <14)
if (!(age>=14 && age<= 90)){
    alert()
}