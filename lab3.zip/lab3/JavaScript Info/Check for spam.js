function checkSpam(str){
    return(str.toLowerCase().indexOf("viagra") != 0 ||str.toLowerCase().indexOf("xxx") != 0);
}