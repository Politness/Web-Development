let map = new Map();
map.set("name", "John");
let keys = Array.from(map.keys());
