let a = 1, b = 1;

let c = ++a; // 2
let d = b++; // 1