alert( 1 && null && 2 ); // null
