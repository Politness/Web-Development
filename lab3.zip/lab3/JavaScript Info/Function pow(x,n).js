function pow(x, n){
    return x**n;
}