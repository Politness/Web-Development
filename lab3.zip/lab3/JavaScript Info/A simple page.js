let name = prompt('What is your name?');
alert(`Hello, ${name}!`);